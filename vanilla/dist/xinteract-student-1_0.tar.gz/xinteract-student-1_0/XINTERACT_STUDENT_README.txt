XInteract Student Interface 1.0
========================================

The XInteract Student interface is used for solving problems and for making the desktop available to the professor for viewing. To launch the student's interface, simply run "java -jar xinteract-student-1_0.jar" from the directory containing this readme file. Note that the Apache Derby database must be running on aldenv149.allegheny.edu before this program is launched. If any changes are made to this database by the instructor, the student interface will need to be closed and re-opened in order for the changes to appear. If you have any difficulties using this interface, please see the instructor in charge of the course.

This system is licensed under GNU GPL v2. See LICENCE.txt for details.
