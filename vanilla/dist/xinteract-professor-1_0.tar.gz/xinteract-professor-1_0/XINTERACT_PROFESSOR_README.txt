XInteract Professor Interface 1.0
========================================

The XInteract Professor interface is used for creating problems, categories, classes, and student, and for managing the relationships between all of the above. To launch the professor's interface, simply run "java -jar xinteract-professor-1_0.jar" from the directory containing this readme file. Note that the Apache Derby database must be running on aldenv149.allegheny.edu before this program is launched. We apologize for hardcoding this hostname. Please see one of the XInteract experts (Alexander Conrad, Radu Creanga, or Erik Ostrofsky) if you encounter troubles.

Please note that, as of this writing, each of the professors in the department has both a professor-side and a student-side account. Each of these accounts stores a different password, but currently each password is blank. Please change your passwords before students get their hands on the system!

This system is licensed under GNU GPL v2. See LICENCE.txt for details.
